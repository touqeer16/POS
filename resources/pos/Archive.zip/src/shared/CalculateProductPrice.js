export const calculatePrice = (cartItem) => {
    const tax = calculateTax(cartItem);
    const amountTax = +cartItem.product_row.product.unit_price * tax / 100;

    // prepare a price for single item
    let price = cartItem.product_row.product.tax_type === 'exclusive' ? +cartItem.product_row.product.unit_price :
        +cartItem.product_row.product.unit_price + +amountTax.toFixed(2);
    // prepare modifiers
    // const modifierPrice = calculateModifierAmount(cartItem);
    const qty = cartItem.product_row.quantity ?? 0;
    // const subAmount = price;
    const subTotalAmount = price * qty;
    const discount = cartItem.product_row.discount && cartItem.product_row.discount.discount_amount ? countDiscount(cartItem, subTotalAmount) : 0;
    // const tax = calculateTax(cartItem);
    let totalAmount = subTotalAmount - discount;
    let modifiersTax = 0;
    let totalModifierPrice = 0;

    if (cartItem.modifiers.length > 0) {
        let totalTax = 0;
        cartItem.modifiers.forEach(modifier => {
            // if (modifier.tax_dropdown) {
                const modifierTax = calculateModifierTax(modifier);

                const modifierPrice = parseFloat(modifier.default_sell_price);
                totalModifierPrice = totalModifierPrice + modifierPrice;

                if (modifierTax > 0) {
                    totalTax = modifierPrice * modifierTax /100;
                    modifiersTax = modifiersTax + totalTax;
                }
            // }
        })
        const subtotalModifiers = totalModifierPrice * qty;
        const subtotalModifierTax = +modifiersTax.toFixed(2) * qty;

        totalAmount = totalAmount + subtotalModifierTax + subtotalModifiers;
    }

    return totalAmount.toFixed(2);
}

// Calculate total price of cart
export const calculateCartTotalPrice = (carts) => {
    let totalAmount = 0;
    carts.forEach(cart => {
        totalAmount = totalAmount + parseFloat(calculatePrice(cart))
    })

    return totalAmount.toFixed(2);
};

const countDiscount = (cartItem, price) => {
    if (cartItem.product_row.discount.discount_type === "percentage") {
        return (+price / 100) * +cartItem.product_row.discount.discount_amount;
    }

    return +cartItem.product_row.discount.discount_amount;
};

const calculateTax = (cartItem) => {
    let tax = 0;
    if (cartItem.product_row.product.tax_id != null) {
        const selectedTax = cartItem.product_row.all_tax_dropdown.filter((t) => t.id === +cartItem.product_row.product.tax_id);
        if (selectedTax.length > 0) {
            tax = selectedTax[0].amount;
        }
    } else {
        if (cartItem.product_row.tax_dropdown) {
            tax = cartItem.product_row.tax_dropdown.amount;
        } else {
            tax = +cartItem.product_row.product.tax_id;
        }
    }

    return +tax;
};

const calculateModifierTax = (cartItem) => {
    let tax = cartItem.tax_dropdown ? cartItem.tax_dropdown.amount : 0;

    return +tax;
};

// Calculate total Tax of cart
export const calculateCartTotalTax = (carts) => {
    let totalAmount = 0;
    carts.forEach(cartItem => {
        let modifiersTax = 0;
        let modifierPrice = 0;
        let totalTax = 0;
        const qty = cartItem.product_row.quantity ?? 0;

        cartItem.modifiers.forEach(modifier => {
            if (modifier.tax_dropdown) {
                const tax = calculateModifierTax(modifier);
                modifierPrice = parseFloat(modifier.default_sell_price);

                if (tax > 0) {
                    const qtyTax = modifierPrice * qty;
                    totalTax = qtyTax * tax /100;
                    modifiersTax = modifiersTax + totalTax;
                }
            }
        })
        if (cartItem.product_row.tax_dropdown) {
            let price = +cartItem.product_row.product.unit_price;
            const discount = cartItem.product_row.discount && cartItem.product_row.discount.discount_amount ? countDiscount(cartItem, price) : 0;
            const modifiers = cartItem.modifiers ?? [];
            let modifierPrice = 0;
            const tax = calculateTax(cartItem);
            modifiers.forEach(modifier => {
                modifierPrice = modifierPrice + parseFloat(modifier.sell_price_inc_tax);
            });

            if (tax > 0) {
                // const totalPrice = (price - discount) * qty
                // const taxAmount = totalPrice * tax / 100;
                const taxAmount = price * tax / 100;
                const taxQTY = taxAmount.toFixed(2) * qty;

                // totalAmount = totalAmount + taxAmount + modifiersTax;
                totalAmount = totalAmount + taxQTY + modifiersTax;
            }
        } else {
            totalAmount = totalAmount + modifiersTax
        }
    });
    return totalAmount.toFixed(2);
};

export const calculateCartTotalModifierTax = (carts) => {
    let totalAmount = 0;
    carts.forEach(cartItem => {
        let totalTax = 0;
        let modifierPrice = 0;
        const qty = cartItem.product_row.quantity ?? 0;

        cartItem.modifiers.forEach(modifier => {
            if (modifier.tax_dropdown) {
                const tax = calculateModifierTax(modifier);
                modifierPrice = parseFloat(modifier.default_sell_price);

                if (tax > 0) {
                    const qtyTax = modifierPrice * qty;
                    totalTax = qtyTax * tax /100;
                    totalAmount = totalAmount + totalTax;
                }
            }
        })
    });
    return totalAmount.toFixed(2);
};

// Calculate total Discount of cart
export const calculateCartTotalDiscount = (carts) => {
    let totalAmount = 0;

    carts.forEach(cartItem => {
        totalAmount = totalAmount + calculateProductDiscount(cartItem);
    });

    return parseFloat(totalAmount).toFixed(2);
}

const calculateModifierAmount = (cartItem) =>{
    const modifiers = cartItem.modifiers ?? [];
    let modifierPrice = 0;
    modifiers.forEach(modifier => {
        modifierPrice = modifierPrice + (+modifier.sell_price_inc_tax);
    });

    return +modifierPrice.toFixed(2);
}

// Calculate Discount of one Product
export const calculateProductDiscount = (cartItem) => {

    if (!cartItem.product_row.discount || !cartItem.product_row.discount.discount_amount) {
        return 0;
    }

    // prepare a price for single item
    const price = +cartItem.product_row.product.default_sell_price;
    // prepare modifiers
    const modifierPrice = calculateModifierAmount(cartItem);
    const qty = cartItem.product_row.quantity ?? 0;
    const subAmount = price + modifierPrice * qty;
    return countDiscount(cartItem, subAmount);
}
