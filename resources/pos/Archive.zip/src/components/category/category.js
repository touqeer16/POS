import React, {useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {fetchCategory} from "../../store/action/categoryAction";
import {fetchProductClickable, fetchProducts} from "../../store/action/allproductAction";

const Category = (props) => {
    const {fetchCategory, category, selectedLocationId, fetchProductClickable, fetchProducts} = props;
    const [categoryName, setCategoryName] = useState('All');

    useEffect(() => {
        fetchCategory();
    }, []);

    const onSelectCategory = (category) => {
        setCategoryName(category.name);
        fetchProductClickable(category.id, selectedLocationId);
    };

    const onSelectAll = () => {
        fetchProducts(selectedLocationId);
        setCategoryName('All');
    };

    const onSelectFavorite = () => {
        fetchProducts(selectedLocationId, 1);
        setCategoryName("Favorites");
    };

    return (
        <div>
            <div className="breadcrumb-nav d-flex justify-content-between align-items-center pe-3">
                <a href="#"
                   className="btn breadcrumb-nav__nav-title text-decoration-none text-primary rounded-0 border-0">
                    {categoryName}
                </a>

                <div className="top-bar_btn-grp">
                    <button type="button" onClick={() => onSelectAll()}
                            className="btn btn-primary top-bar__text-btn breadcrumb-nav__small-btn me-2 text-white">
                        ALL
                    </button>
                    <button type="button" onClick={() => onSelectFavorite()}
                            className="btn btn-primary top-bar__text-btn breadcrumb-nav__favorite-btn text-white">
                        <i className="fa fa-heart" aria-hidden="true"/>
                    </button>
                </div>
            </div>
            {category.categories && category.categories.length === 0 ?
                <div className="mini-box p-2 overflow-hidden" key={category.id}>
                    <div className="row gx-0 flex-nowrap overflow-auto">
                        <div
                            className='mini-box__block active text-primary d-flex align-items-center justify-content-center categories-box'>
                            <h5>No category</h5>
                        </div>
                    </div>
                </div> : ''
            }
            <div className="mini-box p-2 overflow-hidden">
                <div className="row gx-0 flex-nowrap overflow-auto">
                    {category.categories && category.categories.map((category, index) => {
                        return (
                            <div
                                className={`${categoryName === category.name ? 'active' : 'inactive'} mini-box__block active text-primary d-flex align-items-center justify-content-center`}
                                onClick={() => onSelectCategory(category)} key={index}>
                                {(category.image != null) ?
                                    <div>
                                    <img src={category.image_url} className="d-block mx-auto mt-2" alt={category.name}
                                         width="60" height="53"/>
                                        {category.name}
                                    </div>: category.name}
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    )
};

Category.propTypes = {
    OnClickAllCategoryButton: PropTypes.func,
    fetchCategory: PropTypes.func,
    fetchProductClickable: PropTypes.func,
    fetchProducts: PropTypes.func,
};
const mapStateToProps = (state) => {
    const {category} = state;
    return {category};
};

export default connect(mapStateToProps, {fetchCategory, fetchProductClickable, fetchProducts})(Category);

