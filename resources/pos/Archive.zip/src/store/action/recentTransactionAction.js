import apiConfig from "../../config/apiConfig";
import {constants, recentTransactionActionType, toastType} from "../../constants";
import {setLoading} from "./progressBarAction";

export const fetchFinalTransaction = (statusId, isLoading = true) => async (dispatch) => {
    if (isLoading) {
        dispatch(setLoading(true))
    }
    await apiConfig.get(`get-recent-transactions?status=${statusId}`)
        .then((response) => {
            dispatch({type: recentTransactionActionType.FETCH_FINAL_TRANSACTION, payload: response.data.transactions});
            if (isLoading) {
                dispatch(setLoading(false))
            }
        })
        .catch(({response}) => {
            dispatch({
                type: constants.ADD_TOAST,
                payload: {text: response.data.message, type: toastType.ERROR, display: true}
            });
            if (isLoading) {
                dispatch(setLoading(false))
            }
        });
};

export const deleteTransaction = (transactionId) => async (dispatch) => {
    await apiConfig.post(`recent-transaction-delete?transaction_id=${transactionId}`)
        .then(() => {
            dispatch({type: recentTransactionActionType.DELETE_TRANSACTION, payload: transactionId});
        })
        .catch(({response}) => {
            dispatch({
                type: constants.ADD_TOAST,
                payload: {text: response.data.message, type: toastType.ERROR, display: true}
            });
        });
};
