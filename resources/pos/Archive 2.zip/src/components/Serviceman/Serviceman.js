import React, {useEffect, useState} from "react";
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {fetchServiceman} from "../../store/action/servicemanAction";
import {ESCAPE_KEYS, useEventListener} from "../../shared/UseEventListener";

const Serviceman = (props) => {
    const {fetchServiceman, serviceman, selectedLocationId, onSelectService, serviceId} = props;
    const [isServicesToggleModal, setIsServiceToggleModal] = useState(false);
    const [selectServiceId, setSelectServiceId] = useState(serviceId);

    const onServiceClickToggleModal = () => {
        setIsServiceToggleModal(!isServicesToggleModal);
    };

    const onServiceToggleModal = () => {
        setIsServiceToggleModal(!isServicesToggleModal);
        setSelectServiceId('');
    };

    useEffect(() => {
        setSelectServiceId(serviceId ? serviceId : null);
    }, [isServicesToggleModal]);

    useEffect(() => {
        document.body.style.overflow = isServicesToggleModal
            ? 'hidden'
            : 'unset';
    });

    useEffect(() => {
        fetchServiceman(selectedLocationId);
    }, [selectedLocationId]);

    const onSelectServiceMan = (serviceMan) => {
        const id = serviceMan.id === selectServiceId ? null : serviceMan.id;
        setSelectServiceId(id);
    };

    // User for Close the model on Escape
    function handler({key}) {
        if (ESCAPE_KEYS.includes(String(key))) {
            setIsServiceToggleModal(false);
            setSelectServiceId('');
        }
    }

    // listen a event of keydown for ESCAPE and close a model
    useEventListener('keydown', handler);

    const addProductServiceman = () => {
        onSelectService(selectServiceId);
        setIsServiceToggleModal(false);
    };

    const loadServiceMan = (serviceMan, index) => {
        return (
            <button type="button" key={index}
                    className={`${selectServiceId === serviceMan.id ? "service-active" : ''} serviceman-modal__service-btn btn btn-outline-dark d-flex align-items-center justify-content-center`}
                    onClick={() => onSelectServiceMan(serviceMan)}>
                {serviceMan.full_name}
            </button>
        )
    }

    const displayLabel = () => {
        return (<button type="button"
                        className="btn text-primary w-100 h-100 coustom-hover"
                        data-bs-toggle="modal"
                        data-bs-target="#servicemanModal"
                        onClick={onServiceClickToggleModal}
        >
            Serviceman
        </button>)
    }

    if (!isServicesToggleModal) {
        return displayLabel();
    }

    return (
        <div>
            {displayLabel()}
            <div className={`serviceman-modal pos-modal`}>
                <div
                    className="modal-dialog modal-dialog-centered hide-show-dialog">
                    <div className="modal-content border-0 px-4 py-2">
                        <button type="button" className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                                onClick={onServiceToggleModal}
                                onKeyPress={onServiceToggleModal}>X
                        </button>
                        <div className="modal-body">
                            <div className="row">
                                <div
                                    className="col-lg-11 col-12 border-4 border-lg-end pe-lg-0 pe-sm-4 mb-5">
                                    <div
                                        className="pe-lg-2 me-lg-1 mt-4 mt-sm-5 mt-lg-0">
                                        <h5 className="modal-title border-bottom border-4 mb-3 mt-1 mt-sm-0"
                                            id="servicemanModalLabel">
                                            Serviceman
                                        </h5>
                                        <div className="custom-scrollbar">
                                            <div
                                                className="serviceman-modal__main-box bg-secondary">
                                                <div
                                                    className="serviceman-modal__service-btn-grp pt-3 px-2 pb-5 d-flex flex-wrap">
                                                    {serviceman.service_staff && serviceman.service_staff.map((serviceMan, index) => {
                                                        return loadServiceMan(serviceMan, index);
                                                    })}
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-end mt-5">
                                    <button type="button"
                                            // disabled={selectServiceId=== null}
                                            onClick={addProductServiceman}
                                            className="btn btn-primary modal-btn modal-footer-btn serviceman-modal__add-btn mt-3">
                                        Add
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bg-overlay" onClick={onServiceClickToggleModal}
                     role="button" tabIndex="0" aria-label="background overlay"
                     onKeyDown={onServiceClickToggleModal}>{}</div>
            </div>
        </div>
    )
};
Serviceman.propTypes = {
    fetchServiceman: PropTypes.func,
};

const mapStateToProps = (state) => {
    const {serviceman} = state;
    return {serviceman};
};

export default connect(mapStateToProps, {fetchServiceman})(Serviceman);
