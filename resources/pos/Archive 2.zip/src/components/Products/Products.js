import React, {useEffect, useState} from "react";
import PropTypes from "prop-types";
import {connect} from "react-redux";
import {fetchProducts} from "../../store/action/allproductAction";
import {fetchProduct} from "../../store/action/fetchProduct";
import AddProductModifier from "./AddProductModifier";
import {CommonLoading} from "react-loadingg";
import {difference, pluck} from "../../helpers";
import {toFixedTrunc} from "../../shared/CalculateProductPrice"

const Products = (props) => {
    const {
        fetchProducts,
        products,
        cartProducts,
        selectedLocationId,
        updateCart,
        fetchProduct,
        isLoading
    } = props;

    const [carts, setCarts] = useState([]);
    const [cartProductIds, setCartProductIds] = useState([]);
    const [product, setProduct] = useState(null);
    const [isModifierModelOpen, setIsModifierModelOpen] = useState(false);

    useEffect(() => {
        fetchProducts(selectedLocationId);
    }, []);

    useEffect(() => {
        // update cart while cart is updated
        setCarts(cartProducts);
        const ids = cartProducts.map(item => {
            return item.product_row.product.variation_id
        })
        setCartProductIds(ids);
    }, [cartProducts]);

    const closeModifierModel = () => {
        setIsModifierModelOpen(false);
    }

    const addProductToCart = (cartProduct) => {
        const variationId = cartProduct.product_row.product.variation_id;
        let isNew = true;
        const existingCarts = carts.filter((e) => {
            if (e.product_row.product.variation_id !== variationId || cartProduct.modifiers.length !== e.modifiers.length) {
                return e;
            } else {
                const cartModifierIds = pluck(cartProduct.modifiers, 'id')
                const eModifierIds = pluck(e.modifiers, 'id')
                const diff = difference(cartModifierIds, new Set(eModifierIds))
                if (diff.size === 0) {
                    e.product_row.quantity = parseInt(e.product_row.quantity) + 1;
                    isNew = false;
                }
                return e;
            }
        })

        if (isNew) {
            existingCarts.push(cartProduct);
            const existingCartIds = cartProductIds.filter((id) => id !== variationId)
            setCartProductIds([...existingCartIds, variationId])
        }

        setCarts(existingCarts)
        updateCart(existingCarts);

        closeModifierModel();
    }

    const isProductExistInCart = (productId) => {
        return cartProductIds.includes(productId);
    }

    const addToCart = (product) => {
        let isCheckModifier = true;
        // if (isProductExistInCart(product.id)) {
        //     const existingCartProducts = carts.filter((e) => e.product_row.product.variation_id === product.id)
        //     const length = existingCartProducts.length;
        //     if (length > 0) {
        //         setProduct(existingCartProducts[length-1]);
        //         if (existingCartProducts[length-1].modifiers) {
        //             setIsModifierModelOpen(true);
        //         }
        //         isCheckModifier = false;
        //     }
        // }
        // if (isCheckModifier) {
        checkProductInStock(product);
        // }
    };

    const checkProductInStock = (product) => {
        fetchProduct(selectedLocationId, product.id, (cb) => {
            if (cb.product) {
                setProduct(cb.product);
                let taxId = null;
                if (cb.product.product_row.product.tax_dropdown != null) {
                    taxId = cb.product.product_row.product.tax_dropdown[0].id
                }

                cb.product.product_row.product.tax_id = taxId;
                if (cb.product.modifier_products.length) {
                    setIsModifierModelOpen(true);
                } else {
                    cb.product.modifiers = [];
                    addProductToCart(cb.product)
                }
            }
        });
    }

    const sellingPrice = (product) => {
        const countUnitPrice = toFixedTrunc(product.selling_price, 2);

        if (product.product_tax) {
            const taxIntValue = (Math.ceil(product.product_tax * 100) / 100);
            const totalPrice = +countUnitPrice + taxIntValue;
            return totalPrice.toFixed(2)
        } else {
            return countUnitPrice;
        }

    };

    const loadProductCard = (product, index) => {
        return (
            <div className="food-container__item-block" key={index}>
                <div
                    className={`${isProductExistInCart(product.id) ? 'product-active' : ''} card border-0 rounded-3`}
                    data-bs-toggle="modal"
                    data-bs-target="#addProductModal"
                    onClick={() => addToCart(product, index)}
                >
                    <div
                        className="card-header text-white rounded-top text-center">
                        {product.name}
                    </div>
                    <div className="card-body">
                        <img src={product.product_image_url}
                             className="d-block mx-auto my-2"
                             alt="burger"
                             width="80" height="73"/>
                        {/*<p className="text-primary text-center mb-0 food-container__price">*/}
                        {/*    {parseFloat(product.selling_price).toFixed(2)}*/}
                        {/*</p>*/}
                        <p className="text-primary text-center mb-0 food-container__price">
                            {sellingPrice(product)}
                        </p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="position-relative">
            <div className="food-container p-2">
                <div className="row gx-0">
                    {
                        products.length !== 0 ? products.map((product, index) => {
                            return loadProductCard(product, index);
                        }) : isLoading ? <CommonLoading/> :
                            <h3 className="text-center">No Product Available</h3>
                    }
                </div>
            </div>
            {isModifierModelOpen && <AddProductModifier
                product={product}
                addProductInToCart={addProductToCart}
                closeModifierModel={closeModifierModel}/>}
        </div>
    )
}

Products.propTypes = {
    fetchProducts: PropTypes.func,
    fetchProduct: PropTypes.func,
};

const mapStateToProps = (state) => {
    const {products, isLoading} = state;
    return {products, isLoading};
};

export default connect(mapStateToProps, {fetchProducts, fetchProduct})(Products);
