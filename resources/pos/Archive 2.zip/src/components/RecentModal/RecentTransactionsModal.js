import React, {useEffect, useRef, useState} from 'react';
import '../scss/layout.scss';
import {Tab, Tabs} from 'react-bootstrap';
import PropTypes from "prop-types";
import {connect} from "react-redux";
import {deleteTransaction, fetchFinalTransaction} from "../../store/action/recentTransactionAction";
import {CommonLoading} from "react-loadingg";
import DeleteRecentTransactionModal from "./DeleteRecentTransactionmodal";
import {editSuspendedSales} from "../../store/action/suspendedSalesAction";
import {useReactToPrint} from "react-to-print";
import moment from "moment";
import {ESCAPE_KEYS, useEventListener} from "../../shared/UseEventListener";
import {toFixedTrunc} from "../../shared/CalculateProductPrice";

class PrintData extends React.PureComponent {
    render() {
        const transaction = this.props.transactionDetails;
        let modifierText = [];
        if (!transaction) {
            return <div/>
        }

        const countTotalTax = (tax) => {
            let totalAmount = 0;

            tax.print && tax.print.appliedTax.forEach(cartItem => {
                totalAmount = totalAmount + (Math.ceil(cartItem.tax_amount * 100) / 100);
            });

            return +totalAmount.toFixed(2);
        }

        const totalProductTax = countTotalTax(transaction);
        const totalModifierTax = transaction.print.modifier_tax;
        const taxAmount = totalProductTax + totalModifierTax;
        const subTotalRounded = (transaction.print.final_total - parseFloat(taxAmount).toFixed(2));

        const loadFreeModifiers = (modifiers) => {
            let modifierText = [];
            modifiers.forEach((modifier) => {
                if (+modifier.sell_price_inc_tax === 0) {
                    modifierText.push(modifier.variation);
                }
            });

            if (modifierText.length === 0) {
                return '';
            }

            return (
                <tr>
                    <td/>
                    <td style={{'fontSize': '14px'}}>{modifierText.join(',')}</td>
                    <td style={{"textAlign": "end", "padding": "0"}}/>
                    <td style={{'textAlign': 'end', 'padding': '0',}}/>
                    <td style={{'textAlign': 'end', 'padding': '0',}}/>
                </tr>
            )
        }

        return (
            <div style={{"fontFamily": "'Playfair Display', serif"}}>
            <div style={{'width': '100%', 'padding': '25px'}}>
                <table style={{ 'width': '100%' }}>
                    <tbody>
                    <tr>
                        <th style={{
                            'fontWeight': 'unset',
                            'width': '50%',
                        }}>{moment(new Date()).format('DD/MM/YYYY')}</th>
                        <th style={{
                            'fontWeight': 'unset',
                            'width': '50%',
                        }}>POS- الك شاورما
                        </th>
                    </tr>
                    </tbody>
                </table>
                <br/>
                <table style={{"width": "100%", "marginBottom": "5px"}}>
                    <div style={{"fontWeight": "unset"}}
                         dangerouslySetInnerHTML={{__html: transaction.print.header_text}}/>
                </table>
                <table style={{"width": "100%"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr style={{"width": "100%"}}>
                        <td style={{'textAlign': 'start', "width": "100%"}}>
                            <p style={{'margin': '0'}}><b
                                style={{"fontSize": "21px", "textTransform": "uppercase"}}>{transaction.print.location_name}</b>
                                <br/>
                                {transaction.print.address}
                                <br/>
                                <b style={{"fontSize": '14px'}}>VAT:</b> 123456789vat
                                <br/>
                                <b style={{
                                    "fontSize": "15px"
                                }}>{transaction.print.invoice_heading}</b>
                            </p>
                            <hr style={{"border": "1px solid #000000", "marginBottom": "0", "marginTop": "15px"}}/>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <table style={{"width": "100%", "marginBottom": "5px"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr>
                        <th style={{
                            "textAlign": "start",
                            "fontWeight": "unset",
                            "width": "100%",
                            "padding": "0",
                        }}><b>{transaction.print.invoice_no_prefix}</b></th>
                        <th></th>
                        <th style={{
                            "textAlign": "end",
                            "fontWeight": "unset",
                            "padding": "0"
                        }}>{transaction.print.invoice_no}</th>
                    </tr>
                    </tbody>
                </table>
                <table style={{"width": "100%", "marginBottom": "10px"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr>
                        <th style={{
                            "textAlign": "start", "fontWeight": "unset", "padding": "0"
                        }}><b>{transaction.print.date_label}</b></th>
                        <td style={{
                            "textAlign": "end", "fontWeight": "unset", "padding": "0", "whiteSpace": "nowrap"
                        }}>{transaction.print.invoice_date}</td>
                    </tr>
                    </tbody>
                </table>
                <table style={{"width": "100%", "marginBottom": "5px"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr>
                        <th style={{"borderBottom": " 2.5px dashed #b3b2b2", "paddingLeft": "5px"}}>#</th>
                        <th style={{
                            "width": "45%",
                            "padding": "5px",
                            "borderBottom": "2.5px dashed #b3b2b2"
                        }}>{transaction.print.table_product_label}
                        </th>
                        <th style={{
                            "textAlign": "right",
                            "padding": "0",
                            "borderBottom": "2.5px dashed #b3b2b2"
                        }}>{transaction.print.table_qty_label}
                        </th>
                        <th style={{
                            "textAlign": "right",
                            "padding": "0",
                            "borderBottom": "2.5px dashed #b3b2b2"
                        }}>{transaction.print.table_unit_price_label}
                        </th>
                        <th style={{
                            "textAlign": "right",
                            "padding": "0",
                            "borderBottom": "2.5px dashed #b3b2b2"
                        }}>{transaction.print.table_subtotal_label}
                        </th>
                    </tr>
                    {
                        transaction.print && transaction.print.lines.map((line, index) => {
                            const unitPriceRounded = toFixedTrunc(line.unit_price, 2);
                            const roundedValue = +unitPriceRounded + Math.ceil(line.single_product_tax * 100) / 100;
                            const subTotalFinal = +roundedValue * line.quantity;
                            return (
                                <>
                                <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td>{line.name}</td>
                                    <td style={{"textAlign": "end", "padding": "0"}}>{line.quantity} {line.units}</td>
                                    <td style={{"textAlign": "end", "padding": "0"}}>{+roundedValue}</td>
                                    <td style={{"textAlign": "end", "padding": "0"}}>
                                        {subTotalFinal.toFixed(2)}
                                    </td>
                                </tr>
                                    {
                                        line.modifiers && line.modifiers.length !== 0 ?
                                            line.modifiers.map((modifier, index) => {
                                                if (+modifier.sell_price_inc_tax === 0) {
                                                    modifierText.push(modifier.variation);
                                                }
                                                const roundedValue = parseFloat(modifier.unit_price_inc_tax) + modifier.single_modifier_tax;
                                                if (+modifier.sell_price_inc_tax > 0) {
                                                    return (
                                                        <tr key={index}>
                                                            <td/>
                                                            <td style={{'fontSize': '14px'}}>{modifier.variation}</td>
                                                            <td style={{
                                                                "textAlign": "end",
                                                                "padding": "0",
                                                                'fontSize': '14px'
                                                            }}>
                                                                {modifier.quantity} {modifier.units}
                                                            </td>
                                                            <td style={{
                                                                'textAlign': 'end',
                                                                'padding': '0',
                                                                'fontSize': '14px'
                                                            }}>
                                                                {roundedValue.toFixed(2)}
                                                            </td>
                                                            <td style={{
                                                                'textAlign': 'end',
                                                                'padding': '0',
                                                                'fontSize': '14px'
                                                            }}>
                                                                {modifier.sub_total_final.toFixed(2)}
                                                            </td>
                                                        </tr>
                                                    )
                                                }
                                            }) : null
                                    }
                                    {line.modifiers && line.modifiers.length !== 0 && loadFreeModifiers(line.modifiers)}
                            </>
                            )
                        })
                    }
                    </tbody>
                </table>
                <hr style={{"border": "1px solid black", "marginTop": "15px"}}/>

                <table style={{"width": "100%"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr>
                        <th style={{
                            'textAlign': 'right',
                            'width': '65%',
                            'fontSize': '18px',
                            'padding': '0',
                        }}>{transaction.print.subtotal_label}
                        </th>
                        <th style={{
                            'textAlign': 'end',
                            'fontSize': '18px',
                            'padding': '0',
                        }}>{(subTotalRounded.toFixed(2)) + '﷼ '}
                            {/*{transaction.print.subtotal}*/}
                        </th>
                    </tr>
                    <tr>
                        {/*<td style={{"textAlign": "right", "width": '65%'}}>{transaction.print.tax_label}</td>*/}
                        <td style={{
                            'textAlign': 'right',
                            'width': '65%',
                        }}>Tax
                        </td>
                        <td style={{ 'textAlign': 'end' }}>(+) ﷼ {parseFloat(
                            taxAmount).toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td style={{ 'textAlign': 'right', 'width': '65%' }}><b
                            style={{ 'fontSize': '18px' }}>{transaction.print.total_label}</b>
                        </td>
                        <td style={{ 'textAlign': 'end' }}>
                            <b>{transaction.print.total}</b></td>
                    </tr>
                    {
                        transaction.print.payments && transaction.print.payments.length !== 0 ? transaction.print.payments.map((payment, index) => {
                            return (
                                <tr key={index}>
                                    <td style={{
                                        "textAlign": "right",
                                        "width": '65%',
                                        "fontSize": '15px'
                                    }}>{payment.method}({payment.date})
                                    </td>
                                    <td style={{"textAlign": 'end'}}>{payment.amount}</td>
                                </tr>
                            )
                        }) : null
                    }
                    <tr>
                        <td style={{"textAlign": "right", "width": '65%'}}>{transaction.print.total_paid_label}</td>
                        <td style={{"textAlign": 'end'}}>{transaction.print.total_paid}</td>
                    </tr>
                        <tr>
                            <td style={{"textAlign": "right", "width": '65%'}}>{transaction.print.total_due_label}</td>
                            <td style={{"textAlign": 'end'}}>{transaction.print.total_due} </td>
                        </tr>
                    </tbody>
                </table>
                {/*<hr style={{"border": "1px solid black", "marginTop": " 15px"}}/>*/}
                {/*{*/}
                {/*    transaction && transaction.print.appliedTax.length !== 0 ?*/}
                {/*        <div>*/}
                {/*            <table style={{"width": "100%"}}>*/}
                {/*                <tbody style={{"width": "100%"}}>*/}
                {/*                <tr>*/}
                {/*                    <td>*/}
                {/*                        {*/}
                {/*                            transaction.print.appliedTax.map((line, index) => {*/}
                {/*                                return (*/}
                {/*                                    <div>*/}
                {/*                                        <p style={{"position": 'absolute', 'margin': '0'}}*/}
                {/*                                           key={index}>{line.tax_name}</p>*/}
                {/*                                        <p style={{*/}
                {/*                                            "textAlign": "center",*/}
                {/*                                            'margin': '0'*/}
                {/*                                        }}>{line.tax_amount.toFixed(2)}  ﷼ </p>*/}
                {/*                                    </div>*/}
                {/*                                )*/}
                {/*                            })*/}
                {/*                        }*/}
                {/*                    </td>*/}
                {/*                </tr>*/}
                {/*                </tbody>*/}
                {/*            </table>*/}
                {/*        </div>*/}
                {/*        : ''*/}
                {/*}*/}
                {/*<table style={{"width": "100%"}}>*/}
                {/*    <tbody style={{"width": "100%"}}>*/}
                {/*    <tr>*/}
                {/*        <td>*/}
                {/*            <b>*/}
                {/*                <p style={{"position": 'absolute', 'margin': '0'}}>Total Tax</p>*/}
                {/*                <p style={{"textAlign": "center", 'margin': '0'}}>*/}
                {/*                    {taxAmount ? parseFloat(taxAmount).toFixed(2) : 0} ﷼*/}
                {/*                </p>*/}
                {/*            </b>*/}
                {/*        </td>*/}
                {/*    </tr>*/}
                {/*    </tbody>*/}
                {/*</table>*/}
                <hr style={{'border': '1px solid #000000'}}/>
                <table style={{"width": "100%"}}>
                    <div style={{
                        "fontWeight": "unset"
                    }} dangerouslySetInnerHTML={{__html: transaction.print.footer_text}}/>
                </table>
                <table style={{"width": "100%"}}>
                    <tbody style={{"width": "100%"}}>
                    <tr>
                        <td>
                            <p style={{'textAlign': "center", 'margin': "0"}}>{transaction.print.additional_notes}</p>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            </div>
        )
    }
}

const RecentTransactionsModal = (props) => {
    const {
        onRecentClickToggleModal,
        fetchFinalTransaction,
        recentTransactions,
        isLoading,
        deleteTransaction,
        editSuspendedSales,
        closeModal
    } = props;
    const [isDeleteModal, setIsDeleteModal] = useState(false);
    const [deleteId, setDeleteId] = useState(0);
    const [transactionDetails, setTransactionDetails] = useState(null);
    const [printShow, setPrintShow] = useState(false);

    const componentRef = useRef();

    const onClickDeleteTransaction = (id) => {
        setIsDeleteModal(!isDeleteModal);
        setDeleteId(id);
    }

    useEffect(() => {
        fetchFinalTransaction('final');
    }, []);

    const onChangeRecentTransaction = (status) => {
        fetchFinalTransaction(status);
    };

    const deleteTransactions = (id) => {
        deleteTransaction(id);
        setIsDeleteModal(false);
    };

    const editSuspendSale = (id) => {
        closeModal();
        editSuspendedSales(id);
    };

    const printSuspendSale = (transaction) => {
        setTransactionDetails(transaction);
        setPrintShow(true);
    };

    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    });

    const loadPrintBlock = () => {
        return (
            <div className={'d-none'}>
                {
                    printShow && <PrintData ref={componentRef} transactionDetails={transactionDetails}/>
                }
            </div>
        );
    }

    const loadTransactions = (recentTransaction, index) => {
        return (
            <table key={index}
                   className="table bg-white recent-modal__custom-recent-table table-responsive">
                <tbody
                    className="recent-modal__recent-tbody">
                <tr className="cursor-pointer recent-modal__recent-row">
                    <td>
                        {index + 1}
                    </td>
                    <td className="custom-data">
                        {recentTransaction.invoice_no} {recentTransaction.contact.name}
                    </td>
                    <td className="display_currency"
                        title={parseFloat(recentTransaction.final_total).toFixed(2)}>
                        {parseFloat(recentTransaction.final_total).toFixed(2)}</td>
                    <td className="display_icon">
                        <a href="#" onClick={() => editSuspendSale(recentTransaction.id)} className="delete-sale">
                            <i className="fas fa-pen text-muted" aria-hidden="true" title="Click to edit"/>
                        </a>

                        <a href="#" onClick={() => onClickDeleteTransaction(recentTransaction.id)}>
                            <i className="fa fa-trash text-danger" title="Click to delete"/>
                        </a>
                        {isDeleteModal &&
                        <DeleteRecentTransactionModal onClickDeleteTransaction={onClickDeleteTransaction}
                                                      deleteTransactions={() => deleteTransactions(deleteId)}/>}
                        <a href="#" className="print-invoice-link print-icon"
                           onMouseEnter={() => printSuspendSale(recentTransaction)} onClick={handlePrint}>
                        <i className="fa fa-print text-muted" aria-hidden="true" title="Click to print"/>
                        </a>
                    </td>
                </tr>
                </tbody>
            </table>
        )
    };

    const loadRecentTransaction = () => {
        return (
            <div>
                {
                    recentTransactions.length !== 0 ? recentTransactions.map((recentTransaction, index) => {
                        return loadTransactions(recentTransaction, index);
                    }) : isLoading ? <CommonLoading/> :
                        <h3 className="text-center py-3 highlight-color">No Recent Transactions Available</h3>
                }
            </div>
        )
    };

    // User for Close the model on Escape
    function handler({key}) {
        if (ESCAPE_KEYS.includes(String(key))) {
            onRecentClickToggleModal();
        }
    }

    // listen a event of keydown for ESCAPE and close a model
    useEventListener('keydown', handler);

    return (
        <div className="recent-modal pos-modal">
            <div
                className="modal-dialog modal-dialog-centered hide-show-dialog">
                <div
                    className="modal-content border-0 px-2 px-sm-4 py-2">
                    <button type="button"
                            className="btn-close custom-close-btn"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                            onClick={onRecentClickToggleModal}
                            onKeyPress={onRecentClickToggleModal}>X
                    </button>
                    <div className="modal-body">
                        <div className="row">
                            <div
                                className="col-lg-11 col-12 border-4 border-lg-end pe-lg-0 pe-sm-4 h-top-75">
                                <div
                                    className="mb-5 pe-lg-2 me-lg-1 mt-0 mt-sm-5 mt-lg-0">
                                    <h5 className="modal-title payment-modal__top-title border-bottom border-4 mb-3 pend-sm-90 mb-sm-4 mb-md-3 mt-sm-0 mt-4"
                                        id="paymentModalLabel">
                                        Recent Transactions
                                    </h5>
                                    <Tabs defaultActiveKey="final" onSelect={(e) => onChangeRecentTransaction(e)}
                                          id="uncontrolled-tab-example" className="recent-tabs mb-3">
                                        {/*<i className="fa fa-check"/>*/}
                                        <Tab eventKey="final" title="Final" value={'final'}>
                                            {loadRecentTransaction()}
                                        </Tab>
                                        <Tab eventKey="quotation" title="Quotation" value={'quotation'}>
                                            {loadRecentTransaction()}
                                        </Tab>
                                        <Tab eventKey="draft" title="Draft" value={'draft'}>
                                            {loadRecentTransaction()}
                                        </Tab>
                                        {loadPrintBlock()}
                                    </Tabs>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-overlay"
                 onClick={onRecentClickToggleModal}
                 role="button" tabIndex="0"
                 aria-label="background overlay"
                 onKeyDown={onRecentClickToggleModal}>{}</div>
        </div>
    );
};

RecentTransactionsModal.propTypes = {
    fetchFinalTransaction: PropTypes.func,
    deleteTransaction: PropTypes.func,
    printTransaction: PropTypes.func,
};

const mapStateToProps = (state) => {
        const {recentTransactions, isLoading} = state;
        return {recentTransactions, isLoading};
    };

export default connect(mapStateToProps, {
    fetchFinalTransaction,
    deleteTransaction,
    editSuspendedSales
})(RecentTransactionsModal);

