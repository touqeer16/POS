import React, {useEffect} from "react";
import {fetchLocation} from "../../store/action/dropdownAction";
import {connect} from "react-redux";
import PropTypes from "prop-types";
import {fetchProducts} from "../../store/action/allproductAction";

function DropDown(props) {
    const {fetchLocation, fetchProducts, locations, setSelectBoxId} = props;

    useEffect(() => {
        fetchLocation();
    }, []);

    const OnchangeLocation = (e) => {
        fetchProducts(e.target.value);
        setSelectBoxId(e.target.value);
    }

    return (
        <select className="form-control select2" id="dashboard_location"
                onChange={(e) => OnchangeLocation(e)}
        >
            {locations.business_locations && locations.business_locations.map((location, index) => {
                return (
                    <option value={location.id}
                            className="option-drop option-color-window"
                            selected={location.selected_business_location ==
                            'selected' ? 'selected' : ''}
                            key={index}>{location.name}</option>
                )
            })}
        </select>
    )
}

DropDown.propTypes = {
    fetchLocation: PropTypes.func,
}

const mapStateToProps = (state) => {
    const {locations} = state;
    return {locations};
};

export default connect(mapStateToProps, {fetchLocation, fetchProducts})(DropDown);
