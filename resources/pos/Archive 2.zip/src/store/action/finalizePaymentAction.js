import apiConfig from "../../config/apiConfig";
import {constants, paymentActionType} from "../../constants";

export const finalizePayment = (finalize, cb) => async (dispatch) => {
    await apiConfig.post('finalize-payment', finalize)
        .then((response) => {
            dispatch({ type: constants.ADD_TOAST, payload: {text: response.data.msg, display: true}});
            if (response.data.receipt !== null) {
                dispatch({type: paymentActionType.PAYMENT_PRINT, payload: response.data.receipt.print});
                cb({status: true, receipt: true, data: response.data.receipt.print});
            } else {
                cb({status: false, receipt: false});
            }
        })
        .catch(({response}) => {
            dispatch({ type: constants.ADD_TOAST, payload: {text: response.data.msg, display: true}});
        });
};

export const updateFinalizePayment = (finalize, transactionId, cb) => async (dispatch) => {
    await apiConfig.post(`update-finalize-payment?transaction_id=${transactionId}`, finalize)
        .then((response) => {
            dispatch({type: paymentActionType.PAYMENT_PRINT, payload: response.data.receipt.print});
            if (response.data.receipt !== null) {
                dispatch({type: paymentActionType.PAYMENT_PRINT, payload: response.data.receipt.print});
                cb({status: true, receipt: true, data: response.data.receipt.print});
            } else {
                cb({status: false, receipt: false});
            }
        })
        .catch(({response}) => {
            dispatch({ type: constants.ADD_TOAST, payload: {text: response.data.msg, display: true}});
        });
};