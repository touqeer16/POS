import apiConfig from "../../config/apiConfig";
import {apiBaseURL, constants} from "../../constants";
import {toastType} from '../../constants';

export const fetchProduct = (locationId, variationId, cb) => async (dispatch) => {
    await apiConfig.get(apiBaseURL.GET_PRODUCT_ROW + `?location_id=${locationId}&variation_id=${variationId}`)
        .then((response) => {
            if (response.data.product && response.data.product.product_row) {
                cb({product: response.data.product ? response.data.product : null})
            } else {
                dispatch({ type: constants.ADD_TOAST, payload: {text: response.data.product.msg, type: toastType.ERROR, display: true}});
            }
        })
        .catch(({response}) => {
            dispatch({ type: constants.ADD_TOAST, payload: {text: response.data.message, type: toastType.ERROR, display: true}});
        });
};