import apiConfig from "../../config/apiConfig";
import {closeRegisterActionType, constants, toastType} from "../../constants";

export const fetchCloseRegister = () => async (dispatch) => {
    await apiConfig.get(`cash-register-details`)
        .then((response) => {
            dispatch({type: closeRegisterActionType.FETCH_CLOSE_REGISTER, payload: response.data});
        })
        .catch(({response}) => {
            dispatch({
                type: constants.ADD_TOAST,
                payload: {text: response.data.message, type: toastType.ERROR, display: true}
            });
        });
};

export const cashCloseRegister = (register) => async (dispatch) => {
    await apiConfig.post('cash-close-register', register)
        .then((response) => {
            dispatch({type: closeRegisterActionType.CASH_CLOSE_REGISTER, payload: response.data});
            dispatch({type: constants.ADD_TOAST, payload: {text: "Register closed successfully", display: true}});
            window.location.href = "/cash-register/create?";
            window.location.reload();
        })
        .catch(({response}) => {
            dispatch({
                type: constants.ADD_TOAST,
                payload: {text: response.data.message, type: toastType.ERROR, display: true}
            });
        });
};

