import apiConfig from "../../config/apiConfig";
import {constants, registerDetailsActionType, toastType} from "../../constants";

export const fetchRegisterDetails = () => async (dispatch) => {
    await apiConfig.get(`cash-register-details`)
        .then((response) => {
            dispatch({type: registerDetailsActionType.FETCH_REGISTER_DETAILS, payload: response.data});
        })
        .catch(({response}) => {
            dispatch({
                type: constants.ADD_TOAST,
                payload: {text: response.data.message, type: toastType.ERROR, display: true}
            });
        });
};