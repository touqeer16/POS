import React from "react";
import burgerImg from "../../asstes/images/burger-small.png";

function DummyProducts() {
    return (
        <div className="food-container p-2">
            <div className="row gx-0">
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
                <div className="food-container__item-block card border-0 rounded-0"/>
            </div>
        </div>
    );
}

export default DummyProducts;
