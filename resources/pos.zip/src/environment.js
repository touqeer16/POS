export const environment = {
    // URL: window.location.protocol + '//' + window.location.hostname,
    //URL: 'https://tek-store.net',
    URL: window.location.protocol + '//' + window.location.hostname + ":8000",
    //URL: 'https://fastich.com',
    //URL: 'https://stage.fastich.com',
    //URL: 'https://panel.fastich.com',

}
