<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '2.3',
    'pid' => 4
];
